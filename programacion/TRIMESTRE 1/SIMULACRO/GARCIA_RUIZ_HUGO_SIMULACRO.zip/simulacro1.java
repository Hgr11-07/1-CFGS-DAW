package Tema1;

import java.util.*;

public class simulacro1 {
	
	private static Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		char palo;						//Definimos las variables
		int cont=1;
		
		int baraja=7;
		
		System.out.println("Baraja española, elija el palo que quiere imprimir: Bastos, Copas, Espadas, Oros o Todos"); 	//Imprimimos al usuario que introduzca un caracter para la variable palo
		palo=teclado.next().charAt(0);				//Leemos la variable palo
		
		
		
		while (palo!='B' && palo!='C' && palo!='E' && palo!='O' && palo!='T') {		//Ponemos un bucle por si el usuario introduce un caracter distinto a los que le pide el programa para que le siga pidiendo valores
			
			System.out.println("No ha introducido un valor válido");
			
			System.out.println("Baraja española, elija el palo que quiere imprimir: Bastos, Copas, Espadas, Oros o Todos");
			
			palo=teclado.next().charAt(0);
			
		}
		
		if (palo=='B') {			//Si el usuario introduce B, imprimiremos las cartas del 1 al 7 mediante un contador que se autoimprimirá y sumará hasta llegar al valor de baraja (7) después pondremos las figuras restantes.
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-B, ");
				
				cont++;
				
			}
			
			System.out.print("S-B, C-B, R-B");
			
			
			
		} else if (palo=='C') {						//Si el usuario introduce C, imprimiremos las cartas del 1 al 7 mediante un contador que se autoimprimirá y sumará hasta llegar al valor de baraja (7) después pondremos las figuras restantes.
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-C, ");
				
				cont++;
				
			}
			
			System.out.print("S-C, C-C, R-C");
			
			
			
		} else if (palo=='E') {						//Si el usuario introduce E, imprimiremos las cartas del 1 al 7 mediante un contador que se autoimprimirá y sumará hasta llegar al valor de baraja (7) después pondremos las figuras restantes.
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-E, ");
				
				cont++;
				
			}
			
			System.out.print("S-E, C-E, R-E");
			
			
			
		} else if (palo=='O') {						//Si el usuario introduce O imprimiremos las cartas del 1 al 7 mediante un contador que se autoimprimirá y sumará hasta llegar al valor de baraja (7) después pondremos las figuras restantes.
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-O, ");
				
				cont++;
				
			}
			
			System.out.print("S-O, C-O, R-O");
			
			
			
		} else if (palo=='T') {							//Si el usuario introduce T, imprimiremos las cartas del 1 al 7 de cada palo mediante un contador que se autoimprimirá y sumará hasta llegar al valor de baraja (7) después pondremos las figuras restantes. Como el contador se queda en 7 después de cada while, hay que reiniciarlo y hacer un salto de línea para separar cada palo.
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-B, ");
				
				cont++;
				
			}
			
			System.out.print("S-B, C-B, R-B");
			
			System.out.println("");
			
			cont=1;
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-C, ");
				
				cont++;
				
			}
			
			System.out.print("S-C, C-C, R-C");
			
			System.out.println("");
			
			cont=1;
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-E, ");
				
				cont++;
				
			}
			
			System.out.print("S-E, C-E, R-E");
			
			System.out.println("");
			
			cont=1;
			
			while(cont<=baraja) {
				
				System.out.printf("%d", cont); System.out.print("-O, ");
				
				cont++;
				
			}
			
			System.out.print("S-O, C-O, R-O");
			
			
			
		}
		
	}

}
