package Tema1;

import java.util.*;

public class simulacro2 {
	
	private static Scanner teclado=new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int base;
		
		int contFila=1; // Controla la fila actual
		
		int numero=2; // Primer múltiplo de 2
		
		int mult;
		
		int contEspacio;
		
		System.out.println("Introduce la base del triángulo");
		
		base=teclado.nextInt();
		
		while(contFila<=base) {
			
			contEspacio=contFila; // Controla cuántos números se imprimen por fila
			
			while(contEspacio<base) {
				
				System.out.print("  ");
				contEspacio++;
				
			}
			
			mult=1;
			
			while(mult<=contFila) {
				
				System.out.printf("%d", numero);
				numero +=2; // Siguiente múltiplo de 2
				mult++;
				
			}
			
			System.out.println(); // Salto de línea para la siguiente fila
			contFila++;
			
		}
		
			
		}
		
		
		
		
	}

